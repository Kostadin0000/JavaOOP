package viceCity.core;

import viceCity.Main;
import viceCity.core.interfaces.Controller;
import viceCity.models.guns.Gun;
import viceCity.models.guns.Pistol;
import viceCity.models.guns.Rifle;
import viceCity.models.neighbourhood.GangNeighbourhood;
import viceCity.models.neighbourhood.Neighbourhood;
import viceCity.models.players.CivilPlayer;
import viceCity.models.players.MainPlayer;
import viceCity.models.players.Player;

import java.util.*;
import java.util.stream.Collectors;

import static viceCity.common.ConstantMessages.*;

public class ControllerImpl implements Controller {

    private Map<String, Player> civilPlayerCollection;
    private Deque<Gun> gunCollection;
    private Player mainPlayer;
    private Neighbourhood neighbourhood;

    public ControllerImpl() {
        this.civilPlayerCollection = new LinkedHashMap<>();
        this.gunCollection = new ArrayDeque<>();
        mainPlayer = new MainPlayer();
        this.neighbourhood = new GangNeighbourhood();
    }

    @Override
    public String addPlayer(String name) {
        civilPlayerCollection.put(name, new CivilPlayer(name));
        return String.format(PLAYER_ADDED, name);
    }

    @Override
    public String addGun(String type, String name) {
        Gun gun = null;
        switch (type) {
            case "Pistol":
                gun = new Pistol(name);
                break;
            case "Rifle":
                gun = new Rifle(name);
                break;
            default:
                return String.format(GUN_TYPE_INVALID);
        }
        gunCollection.offer(gun);
        return String.format(GUN_ADDED, name, type);
    }

    @Override
    public String addGunToPlayer(String name) {
        Gun gun = gunCollection.poll();
        if (gun == null) {
            return String.format(GUN_QUEUE_IS_EMPTY);
        }
        if (name.equals("Vercetti")) {
            mainPlayer.getGunRepository().add(gun);
            return String.format(GUN_ADDED_TO_MAIN_PLAYER, gun.getName(), mainPlayer.getName());
        }

        Player player = civilPlayerCollection.get(name);

        if (player == null) {
            return String.format(CIVIL_PLAYER_DOES_NOT_EXIST);
        }

        player.getGunRepository().add(gun);
        return String.format(GUN_ADDED_TO_CIVIL_PLAYER, gun.getName(), player.getName());
    }

    @Override
    public String fight() {
        neighbourhood.action(mainPlayer, civilPlayerCollection.values());

        if (mainPlayer.getLifePoints() == 100 && civilPlayerCollection.
                values().stream().allMatch(p -> p.getLifePoints() == 50)) {
            return FIGHT_HOT_HAPPENED;
        }

        List<Player> dead = civilPlayerCollection.values()
                .stream().filter(p -> !p.isAlive())
                .collect(Collectors.toList());

        StringBuilder sb = new StringBuilder(FIGHT_HAPPENED);

        sb.append(System.lineSeparator())
                .append(String.format(MAIN_PLAYER_LIVE_POINTS_MESSAGE, mainPlayer.getLifePoints()))
                .append(System.lineSeparator())
                .append(String.format(MAIN_PLAYER_KILLED_CIVIL_PLAYERS_MESSAGE,
                        dead.size()))
                .append(System.lineSeparator())
                .append(String.format(CIVIL_PLAYERS_LEFT_MESSAGE, civilPlayerCollection.size() - dead.size()));

        for (Player player : dead) {
            civilPlayerCollection.remove(player);
        }

        return sb.toString();
    }
}
