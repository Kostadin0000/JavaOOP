package viceCity.models.guns;

public class Rifle extends BaseGun {
    private static int BARREL = 50;
    private static int TOTAL = 500;

    public Rifle(String name) {
        super(name, BARREL, TOTAL);
    }

    @Override
    public int fire() {
        if (canFire() && BARREL -5  >= 0) {
            BARREL -= 5;
            return 5;
        } else {
            BARREL = 50;
            TOTAL -= BARREL;
            return 0;
        }
    }
}
