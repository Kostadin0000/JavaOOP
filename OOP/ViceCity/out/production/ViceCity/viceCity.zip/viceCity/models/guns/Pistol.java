package viceCity.models.guns;

public class Pistol extends BaseGun {
    private static int BARREL = 10;
    private static int TOTAL = 100;

    public Pistol(String name) {
        super(name, BARREL, TOTAL);
    }

    @Override
    public int fire() {
        if (canFire() && BARREL - 1 >= 0) {
            BARREL -= 1;
            return 1;
        } else {
            BARREL = 10;
            TOTAL -= BARREL;
            return 0;
        }

    }
}
