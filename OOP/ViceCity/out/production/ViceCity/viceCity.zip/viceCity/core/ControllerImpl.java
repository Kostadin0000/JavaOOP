package viceCity.core;

import viceCity.Main;
import viceCity.core.interfaces.Controller;
import viceCity.models.guns.Gun;
import viceCity.models.guns.Pistol;
import viceCity.models.guns.Rifle;
import viceCity.models.players.CivilPlayer;
import viceCity.models.players.MainPlayer;
import viceCity.models.players.Player;

import java.util.ArrayList;
import java.util.Collection;

import static viceCity.common.ConstantMessages.*;

public class ControllerImpl implements Controller {

    private Collection<Player> civilPlayerCollection;
    private Collection<Gun> gunCollection;
    private MainPlayer mainPlayer;

    public ControllerImpl() {
        this.civilPlayerCollection = new ArrayList<>();
        this.gunCollection = new ArrayList<>();
        mainPlayer = new MainPlayer();
    }

    @Override
    public String addPlayer(String name) {
        Player civilPlayer = new CivilPlayer(name);
        civilPlayerCollection.add(civilPlayer);
        return String.format(PLAYER_ADDED, name);
    }

    @Override
    public String addGun(String type, String name) {
        Gun gun = null;
        switch (type) {
            case "Pistol":
                gun = new Pistol(name);
                break;
            case "Rifle":
                gun = new Rifle(name);
                break;
            default:
                return String.format(GUN_TYPE_INVALID);
        }
        gunCollection.add(gun);
        return String.format(GUN_ADDED, name, type);
    }

    @Override
    public String addGunToPlayer(String name) {

        if (gunCollection.isEmpty()) {
            return String.format(GUN_QUEUE_IS_EMPTY);
        }
        if (name.equals("Vercetti")) {
            Gun gun = (Gun) gunCollection.toArray()[0];
            mainPlayer.getGunRepository().add(gun);
            gunCollection.remove(gun);
            return String.format(GUN_ADDED_TO_MAIN_PLAYER, gun.getName(), mainPlayer.getName());
        }
        for (Player player : civilPlayerCollection) {
            if (player.getName().equals(name)) {
                Gun gun = (Gun) gunCollection.toArray()[0];
                player.getGunRepository().add(gun);
                gunCollection.remove(gun);
                return String.format(GUN_ADDED_TO_CIVIL_PLAYER, gun.getName(), player.getName());
            }
        }
        return String.format(CIVIL_PLAYER_DOES_NOT_EXIST);
    }

    @Override
    public String fight() {
        return ;
    }
}
