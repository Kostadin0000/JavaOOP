package aquarium.entities.aquariums;

import aquarium.entities.decorations.Decoration;
import aquarium.entities.fish.Fish;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;

import static aquarium.common.ConstantMessages.*;
import static aquarium.common.ExceptionMessages.*;

public abstract class BaseAquarium implements Aquarium {
    private String name;
    private int capacity;
    private Collection<Decoration> decorations;
    private Collection<Fish> fishes;


    protected BaseAquarium(String name, int capacity) {
        this.setName(name);
        this.capacity = capacity;
        decorations = new ArrayList<>();
        fishes = new ArrayList<>();
    }

    private void setName(String name) {
        if (name == null || name.trim().isEmpty()) {
            throw new NullPointerException(AQUARIUM_NAME_NULL_OR_EMPTY);
        }
        this.name = name;
    }

    protected int getCapacity() {
        return capacity;
    }

    @Override
    public int calculateComfort() {
        int sum = 0;
        sum = this.decorations.stream().mapToInt(Decoration::getComfort).sum();
        return sum;
    }

    @Override
    public String getName() {
        return name;
    }

    @Override
    public void addFish(Fish fish) {
        if (this.fishes.size() < capacity) {
            this.fishes.add(fish);
        }
        throw new IllegalStateException(NOT_ENOUGH_CAPACITY);
    }

    @Override
    public void removeFish(Fish fish) {
        this.fishes.remove(fish);
    }

    @Override
    public void addDecoration(Decoration decoration) {
        decorations.add(decoration);
    }

    @Override
    public void feed() {
        this.fishes.forEach(Fish::eat);
    }

    @Override
    public String getInfo() {

        StringBuilder sb = new StringBuilder();
        sb.append(String.format("%s (%s):", name, getClass().getSimpleName())).append(System.lineSeparator());
        sb.append("Fish: ");
        for (Fish fish : fishes) {
            sb.append(fish.getName() + " ");
        }
        if (fishes.isEmpty()) {
            sb.append("none");
        }
        sb.append(System.lineSeparator());
        sb.append(String.format("Decorations: %d", decorations.size())).append(System.lineSeparator());
        sb.append(String.format("Comfort: %d", calculateComfort())).append(System.lineSeparator());
        return sb.toString().trim();
    }

    @Override
    public Collection<Fish> getFish() {
        return Collections.unmodifiableCollection(this.fishes);
    }

    @Override
    public Collection<Decoration> getDecorations() {
        return Collections.unmodifiableCollection(this.decorations);
    }
}
