import java.text.DecimalFormat;

public abstract class Vehicle {

    protected double fuelQuantity;
    protected double fuelConsumption;

    protected Vehicle(double fuelQuantity, double fuelConsumption) {
        this.fuelQuantity = fuelQuantity;
        this.fuelConsumption = fuelConsumption;
    }

    public String drive(double distance) {
        double fuelNeeded = this.fuelConsumption * distance;
        if (this.fuelQuantity < fuelNeeded) {
            return this.getClass().getSimpleName() + " needs refueling";
        }
        fuelQuantity -= fuelNeeded;

        DecimalFormat format = new DecimalFormat("##.##");

        return String.format(this.getClass().getSimpleName() + " travelled %s km", format.format(distance));

    }

    public void fuel(double liters) {
        fuelQuantity += liters;
    }

    @Override
    public String toString() {
        return String.format("%s: %.2f", this.getClass().getSimpleName(), fuelQuantity);
    }
}
