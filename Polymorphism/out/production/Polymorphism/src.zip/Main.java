import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        String[] tokens = scanner.nextLine().split(" ");
        Vehicle car = new Car(Double.parseDouble(tokens[1]), Double.parseDouble(tokens[2]));
        tokens = scanner.nextLine().split(" ");
        Vehicle truck = new Truck(Double.parseDouble(tokens[1]), Double.parseDouble(tokens[2]));

        int n = Integer.parseInt(scanner.nextLine());
        for (int i = 0; i < n; i++) {
            String command = scanner.nextLine();
            tokens = command.split(" ");
            double distance = Double.parseDouble(tokens[2]);
            if (tokens[0].equals("Drive")) {
                if (tokens[1].equals("Car")) {
                    System.out.println(car.drive(distance));
                } else {
                    System.out.println(truck.drive(distance));
                }
            } else {
                if (tokens[1].equals("Car")) {
                    car.fuel(distance);
                } else {
                    truck.fuel(distance);
                }

            }
        }

        System.out.println(car.toString());
        System.out.println(truck.toString());
    }
}
