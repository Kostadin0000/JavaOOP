public class Truck extends Vehicle {
    private final static double FUEL_CONSUMPTION = 1.6;


    public Truck(double fuelQuantity, double fuelConsumption) {
        super(fuelQuantity, fuelConsumption + FUEL_CONSUMPTION);
    }
    @Override
    public void fuel(double liters) {
        super.fuel(liters * 0.95);
    }
}
