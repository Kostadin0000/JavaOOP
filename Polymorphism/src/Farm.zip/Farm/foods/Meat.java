package Farm.foods;

import Farm.foods.Food;

public class Meat extends Food {

    public Meat(Integer quantity) {
        super(quantity);
    }
}
