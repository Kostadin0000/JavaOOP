package Second;

public interface Birthable {
    String getBirthDate();
}
