package Second;

public interface Identifiable {
    String getId();

}
