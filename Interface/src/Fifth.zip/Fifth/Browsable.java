package Fifth;

public interface Browsable {
    String browse();
}
