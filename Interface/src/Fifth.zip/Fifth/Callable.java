package Fifth;

public interface Callable {
    String call();
}
