package Fourth;

public interface Buyer extends Person {
    void buyFood();

    int getFood();

}
