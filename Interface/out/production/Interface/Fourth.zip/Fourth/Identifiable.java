package Fourth;

public interface Identifiable {
    String getId();

}
